from pathlib import Path

# Raíz del proyecto = carpeta padre de /scripts
BASE_DIR = Path(__file__).resolve().parent.parent

DATASET_DIR = BASE_DIR / "dataset"
CODEBOOK_DIR = BASE_DIR / "codebook"
SCRIPTS_DIR = BASE_DIR / "scripts"
RESULTS_DIR = BASE_DIR / "results"
NOTEBOOKS_DIR = BASE_DIR / "notebooks"
FIGURES_DIR = BASE_DIR / "figures"
TABLES_DIR = BASE_DIR / "tables"

RAW_DATA_FILE = DATASET_DIR / "NSCH_2023e_Topical_CAHMI_DRC.csv"

CLEAN_DATA_FILE = DATASET_DIR / "nsch_flourishing_clean.csv"
ML_READY_BASIC_FILE = DATASET_DIR / "nsch_2023_flourishing_ml_ready.csv"
ML_READY_FULL_FILE = DATASET_DIR / "nsch_2023_ml_ready_full.csv"
ML_READY_REDUCED_FILE = DATASET_DIR / "nsch_2023_ml_ready_reduced.csv"
ML_READY_SELECTED_FILE = DATASET_DIR / "nsch_2023_ml_ready_selected.csv"
ML_READY_STRICT_FILE = DATASET_DIR / "nsch_2023_ml_ready_strict.csv"

MUTUAL_INFO_FILE = RESULTS_DIR / "mutual_information_scores.csv"
LOGISTIC_COEFFICIENTS_FILE = RESULTS_DIR / "logistic_coefficients.csv"
LOGISTIC_RESULTS_FILE = RESULTS_DIR / "logistic_results.csv"
WEIGHTED_LOGISTIC_RESULTS_FILE = RESULTS_DIR / "weighted_logistic_results.csv"
RF_RESULTS_FILE = RESULTS_DIR / "random_forest_results.csv"
CV_RESULTS_FILE = RESULTS_DIR / "cross_validation_results.csv"
DATASET_SUMMARY_FILE = RESULTS_DIR / "dataset_summary.csv"
TARGET_DISTRIBUTION_FILE = RESULTS_DIR / "target_distribution.csv"
WEIGHTED_COMPARISON_FILE = RESULTS_DIR / "weighted_vs_unweighted_comparison.csv"

CODEBOOK_FILE = CODEBOOK_DIR / "codebook_ml_dataset.csv"
HEATMAP_FILE = FIGURES_DIR / "correlation_heatmap.png"

TABLE_DATASET_FILE = TABLES_DIR / "table_dataset.tex"
TABLE_FEATURE_SELECTION_FILE = TABLES_DIR / "table_feature_selection.tex"
TABLE_MODEL_RESULTS_FILE = TABLES_DIR / "table_model_results.tex"
TABLE_STATE_FLOURISHING_FILE = TABLES_DIR / "table_state_flourishing_top10.tex"
TABLE_WEIGHTED_COMPARISON_FILE = TABLES_DIR / "table_weighted_vs_unweighted.tex"

FIGURE_DATAFLOW_TEX_FILE = FIGURES_DIR / "dataset_flow_diagram.tex"

DIRS = [
    DATASET_DIR,
    CODEBOOK_DIR,
    SCRIPTS_DIR,
    RESULTS_DIR,
    NOTEBOOKS_DIR,
    FIGURES_DIR,
    TABLES_DIR,
]

def ensure_directories() -> None:
    for d in DIRS:
        d.mkdir(parents=True, exist_ok=True)

if __name__ == "__main__":
    ensure_directories()
    print("BASE_DIR:", BASE_DIR)
    print("RAW_DATA_FILE:", RAW_DATA_FILE)
    print("TABLES_DIR:", TABLES_DIR)
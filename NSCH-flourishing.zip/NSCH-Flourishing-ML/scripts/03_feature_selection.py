import pandas as pd
import numpy as np

from pathlib import Path
import importlib.util

from sklearn.feature_selection import mutual_info_classif
from sklearn.model_selection import train_test_split, StratifiedKFold, cross_val_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression

# Cargar dinámicamente 00_setup_paths.py
CURRENT_DIR = Path(__file__).resolve().parent
SETUP_FILE = CURRENT_DIR / "00_setup_paths.py"

spec = importlib.util.spec_from_file_location("setup_paths", SETUP_FILE)
setup_paths = importlib.util.module_from_spec(spec)
spec.loader.exec_module(setup_paths)

setup_paths.ensure_directories()

ML_READY_REDUCED_FILE = setup_paths.ML_READY_REDUCED_FILE
ML_READY_SELECTED_FILE = setup_paths.ML_READY_SELECTED_FILE
ML_READY_STRICT_FILE = setup_paths.ML_READY_STRICT_FILE
MUTUAL_INFO_FILE = setup_paths.MUTUAL_INFO_FILE

FEATURE_SELECTION_DIAGNOSTICS_FILE = setup_paths.RESULTS_DIR / "feature_selection_diagnostics.csv"
SPLIT_ASSIGNMENTS_FILE = setup_paths.RESULTS_DIR / "analysis_split_assignments.csv"

REQUIRED_COLS = ["child_id", "flourishing_all4", "FWC", "STRATUM", "FIPSST"]
INVALID_RESPONSE_CODES = {90, 95, 97, 98, 99}

TEST_SIZE = 0.30
RANDOM_STATE = 42
CV_FOLDS = 5

# Tamaño del dataset "selected" (exploratorio / amplio)
DEFAULT_SELECTED_TOP_K = 50

# Grid para justificar el tamaño del subset estricto
K_GRID_BASE = [10, 20, 30, 40, 50, 60, 80, 100, 150, 200]

# Tolerancia respecto al mejor ROC-AUC medio CV:
# elegimos el menor k cuya media esté dentro de este margen.
STRICT_SELECTION_TOL = 0.002


def clean_features(df: pd.DataFrame) -> pd.DataFrame:
    """
    Limpia la matriz de features para mutual information y modelado.
    - reemplaza blancos por NaN
    - reemplaza códigos especiales por NaN
    - convierte a numérico
    - imputa faltantes con -1
    """
    X = df.copy()
    X = X.replace(r"^\s*$", np.nan, regex=True)
    X = X.replace(list(INVALID_RESPONSE_CODES), np.nan)

    for col in X.columns:
        X[col] = pd.to_numeric(X[col], errors="coerce")

    X = X.fillna(-1)
    return X


def infer_discrete_features(X: pd.DataFrame) -> list[bool]:
    """
    Heurística para mutual_info_classif:
    marca una variable como discreta si:
    - sus valores observados (excluyendo -1) son esencialmente enteros, y
    - su cardinalidad es relativamente pequeña.
    """
    discrete_mask = []

    for col in X.columns:
        s = X[col]
        s_valid = s[s != -1]

        if s_valid.empty:
            discrete_mask.append(True)
            continue

        values = s_valid.to_numpy(dtype=float)
        is_integer_like = np.all(np.isclose(values, np.round(values)))
        nunique = s_valid.nunique(dropna=True)

        discrete_mask.append(bool(is_integer_like and nunique <= 20))

    return discrete_mask


def build_k_grid(n_features: int) -> list[int]:
    grid = sorted({k for k in K_GRID_BASE if 1 <= k <= n_features})
    if n_features not in grid:
        grid.append(n_features)
    return sorted(grid)


def evaluate_k_grid(
    X_train: pd.DataFrame,
    y_train: pd.Series,
    ranked_features: list[str],
) -> pd.DataFrame:
    """
    Evalúa distintos tamaños k del ranking usando CV solo en training.
    Modelo base: Logistic Regression estandarizada.
    """
    cv = StratifiedKFold(n_splits=CV_FOLDS, shuffle=True, random_state=RANDOM_STATE)
    records = []

    k_grid = build_k_grid(len(ranked_features))

    for k in k_grid:
        subset = ranked_features[:k]
        X_k = X_train[subset].copy()

        pipe = Pipeline([
            ("scaler", StandardScaler()),
            ("clf", LogisticRegression(
                max_iter=10000,
                solver="liblinear",
                random_state=RANDOM_STATE
            )),
        ])

        scores = cross_val_score(pipe, X_k, y_train, cv=cv, scoring="roc_auc")

        records.append({
            "k": k,
            "cv_mean_roc_auc": float(scores.mean()),
            "cv_std_roc_auc": float(scores.std(ddof=0)),
        })

    return pd.DataFrame(records).sort_values(by="k").reset_index(drop=True)


def choose_strict_k(diagnostics: pd.DataFrame) -> int:
    """
    Escoge el menor k cuya media CV ROC-AUC esté dentro de una tolerancia
    respecto al mejor valor observado.
    """
    best_mean = diagnostics["cv_mean_roc_auc"].max()
    threshold = best_mean - STRICT_SELECTION_TOL

    eligible = diagnostics[diagnostics["cv_mean_roc_auc"] >= threshold].copy()
    chosen_k = int(eligible["k"].min())
    return chosen_k


def main() -> None:
    if not ML_READY_REDUCED_FILE.exists():
        raise FileNotFoundError(f"No existe el dataset reducido: {ML_READY_REDUCED_FILE}")

    df = pd.read_csv(ML_READY_REDUCED_FILE, low_memory=False)

    missing_required = [c for c in REQUIRED_COLS if c not in df.columns]
    if missing_required:
        raise ValueError(f"Faltan columnas requeridas en el dataset reducido: {missing_required}")

    X_raw = df.drop(columns=REQUIRED_COLS).copy()
    y = df["flourishing_all4"].copy()

    # ------------------------------------------------------------
    # 1. Split estratificado ANTES de feature selection
    # ------------------------------------------------------------
    train_idx, test_idx = train_test_split(
        df.index,
        test_size=TEST_SIZE,
        random_state=RANDOM_STATE,
        stratify=y
    )

    train_idx = sorted(train_idx)
    test_idx = sorted(test_idx)

    split_assignments = pd.DataFrame({
        "child_id": df["child_id"],
        "split": np.where(df.index.isin(train_idx), "train", "test"),
        "flourishing_all4": y
    })
    split_assignments.to_csv(SPLIT_ASSIGNMENTS_FILE, index=False)

    X_train_raw = X_raw.loc[train_idx].copy()
    y_train = y.loc[train_idx].copy()

    # ------------------------------------------------------------
    # 2. Limpiar SOLO training para calcular MI
    # ------------------------------------------------------------
    X_train = clean_features(X_train_raw)

    discrete_mask = infer_discrete_features(X_train)

    mi = mutual_info_classif(
        X_train,
        y_train,
        discrete_features=discrete_mask,
        random_state=RANDOM_STATE
    )

    mi_scores = pd.DataFrame({
        "variable": X_train.columns,
        "mutual_information": mi
    }).sort_values(by="mutual_information", ascending=False).reset_index(drop=True)

    mi_scores["rank"] = np.arange(1, len(mi_scores) + 1)

    ranked_features = mi_scores["variable"].tolist()

    # ------------------------------------------------------------
    # 3. Justificar tamaño del subset estricto con CV en training
    # ------------------------------------------------------------
    diagnostics = evaluate_k_grid(X_train, y_train, ranked_features)
    strict_k = choose_strict_k(diagnostics)

    selected_top_k = max(min(DEFAULT_SELECTED_TOP_K, len(ranked_features)), strict_k)

    top_features_selected = ranked_features[:selected_top_k]
    top_features_strict = ranked_features[:strict_k]

    mi_scores["selected_dataset"] = mi_scores["variable"].isin(top_features_selected).astype(int)
    mi_scores["strict_dataset"] = mi_scores["variable"].isin(top_features_strict).astype(int)

    mi_scores.to_csv(MUTUAL_INFO_FILE, index=False)

    diagnostics["best_cv_mean_roc_auc"] = diagnostics["cv_mean_roc_auc"].max()
    diagnostics["strict_selection_tol"] = STRICT_SELECTION_TOL
    diagnostics["chosen_for_strict"] = (diagnostics["k"] == strict_k).astype(int)
    diagnostics.to_csv(FEATURE_SELECTION_DIAGNOSTICS_FILE, index=False)

    # ------------------------------------------------------------
    # 4. Exportar datasets con las features elegidas
    #    (las features se eligieron usando SOLO training)
    # ------------------------------------------------------------
    cols_selected = REQUIRED_COLS + top_features_selected
    cols_strict = REQUIRED_COLS + top_features_strict

    ml_dataset_selected = df[cols_selected].copy()
    ml_dataset_strict = df[cols_strict].copy()

    ml_dataset_selected.to_csv(ML_READY_SELECTED_FILE, index=False)
    ml_dataset_strict.to_csv(ML_READY_STRICT_FILE, index=False)

    # ------------------------------------------------------------
    # 5. Reporte en consola
    # ------------------------------------------------------------
    print("=== Split reproducible ===")
    print("Train size:", len(train_idx))
    print("Test size:", len(test_idx))

    print("\n=== Top 20 variables por mutual information (training only) ===")
    print(mi_scores[["rank", "variable", "mutual_information"]].head(20).to_string(index=False))

    print("\n=== Diagnóstico de selección de k ===")
    print(diagnostics.to_string(index=False))

    print("\n=== Selección final ===")
    print("selected_top_k:", selected_top_k)
    print("strict_k:", strict_k)

    print("\nShape selected:", ml_dataset_selected.shape)
    print("Shape strict:", ml_dataset_strict.shape)

    print("\nArchivos guardados:")
    print("Split assignments:", SPLIT_ASSIGNMENTS_FILE)
    print("Mutual information:", MUTUAL_INFO_FILE)
    print("Feature selection diagnostics:", FEATURE_SELECTION_DIAGNOSTICS_FILE)
    print("Selected dataset:", ML_READY_SELECTED_FILE)
    print("Strict dataset:", ML_READY_STRICT_FILE)


if __name__ == "__main__":
    main()
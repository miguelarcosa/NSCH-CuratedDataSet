import pandas as pd
import numpy as np

from pathlib import Path
import importlib.util

from sklearn.base import clone
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score

# Cargar dinámicamente 00_setup_paths.py
CURRENT_DIR = Path(__file__).resolve().parent
SETUP_FILE = CURRENT_DIR / "00_setup_paths.py"

spec = importlib.util.spec_from_file_location("setup_paths", SETUP_FILE)
setup_paths = importlib.util.module_from_spec(spec)
spec.loader.exec_module(setup_paths)

setup_paths.ensure_directories()

ML_READY_STRICT_FILE = setup_paths.ML_READY_STRICT_FILE
LOGISTIC_RESULTS_FILE = setup_paths.LOGISTIC_RESULTS_FILE
WEIGHTED_LOGISTIC_RESULTS_FILE = setup_paths.WEIGHTED_LOGISTIC_RESULTS_FILE
RF_RESULTS_FILE = setup_paths.RF_RESULTS_FILE
CV_RESULTS_FILE = setup_paths.CV_RESULTS_FILE
LOGISTIC_COEFFICIENTS_FILE = setup_paths.LOGISTIC_COEFFICIENTS_FILE

# Archivos adicionales para esta versión corregida
RESULTS_DIR = setup_paths.RESULTS_DIR
SPLIT_ASSIGNMENTS_FILE = RESULTS_DIR / "analysis_split_assignments.csv"
WEIGHTED_RF_RESULTS_FILE = RESULTS_DIR / "weighted_random_forest_results.csv"
MODEL_SUMMARY_FILE = RESULTS_DIR / "baseline_model_results_summary.csv"

REQUIRED_COLS = ["child_id", "flourishing_all4", "FWC", "STRATUM", "FIPSST"]
INVALID_RESPONSE_CODES = {90, 95, 97, 98, 99}
RANDOM_STATE = 42
CV_FOLDS = 5


def clean_features(df: pd.DataFrame) -> pd.DataFrame:
    """
    Limpia la matriz de features para modelado.
    - reemplaza blancos por NaN
    - reemplaza códigos especiales por NaN
    - convierte a numérico
    - imputa faltantes con -1
    """
    X = df.copy()
    X = X.replace(r"^\s*$", np.nan, regex=True)
    X = X.replace(list(INVALID_RESPONSE_CODES), np.nan)

    for col in X.columns:
        X[col] = pd.to_numeric(X[col], errors="coerce")

    X = X.fillna(-1)
    return X


def compute_metrics(y_true: pd.Series, y_pred: np.ndarray, y_prob: np.ndarray) -> dict:
    return {
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "f1": float(f1_score(y_true, y_pred)),
        "roc_auc": float(roc_auc_score(y_true, y_prob)),
    }


def fit_and_evaluate_pipeline(
    model_name: str,
    estimator,
    X_train: pd.DataFrame,
    y_train: pd.Series,
    X_test: pd.DataFrame,
    y_test: pd.Series,
    sample_weight: pd.Series | None = None,
    pipeline_step_name: str = "clf",
) -> tuple[pd.DataFrame, object]:
    """
    Ajusta modelo, predice en test y devuelve DataFrame de métricas.
    """
    model = clone(estimator)

    if sample_weight is not None:
        fit_kwargs = {f"{pipeline_step_name}__sample_weight": sample_weight}
        model.fit(X_train, y_train, **fit_kwargs)
    else:
        model.fit(X_train, y_train)

    y_pred = model.predict(X_test)
    y_prob = model.predict_proba(X_test)[:, 1]

    metrics = compute_metrics(y_test, y_pred, y_prob)
    result_df = pd.DataFrame([{
        "model": model_name,
        **metrics
    }])

    return result_df, model


def fit_and_evaluate_estimator(
    model_name: str,
    estimator,
    X_train: pd.DataFrame,
    y_train: pd.Series,
    X_test: pd.DataFrame,
    y_test: pd.Series,
    sample_weight: pd.Series | None = None,
) -> tuple[pd.DataFrame, object]:
    """
    Ajusta estimador directo (sin pipeline), predice en test y devuelve métricas.
    """
    model = clone(estimator)

    if sample_weight is not None:
        model.fit(X_train, y_train, sample_weight=sample_weight)
    else:
        model.fit(X_train, y_train)

    y_pred = model.predict(X_test)
    y_prob = model.predict_proba(X_test)[:, 1]

    metrics = compute_metrics(y_test, y_pred, y_prob)
    result_df = pd.DataFrame([{
        "model": model_name,
        **metrics
    }])

    return result_df, model


def cross_validate_model(
    model_name: str,
    estimator,
    X_train: pd.DataFrame,
    y_train: pd.Series,
    sample_weight: pd.Series | None = None,
    is_pipeline: bool = True,
    pipeline_step_name: str = "clf",
) -> pd.DataFrame:
    """
    Cross-validation únicamente sobre training.
    Guarda ROC-AUC por fold y media.
    """
    cv = StratifiedKFold(n_splits=CV_FOLDS, shuffle=True, random_state=RANDOM_STATE)
    rows = []

    for fold, (tr_idx, va_idx) in enumerate(cv.split(X_train, y_train), start=1):
        X_tr = X_train.iloc[tr_idx]
        X_va = X_train.iloc[va_idx]
        y_tr = y_train.iloc[tr_idx]
        y_va = y_train.iloc[va_idx]

        model = clone(estimator)

        if sample_weight is not None:
            w_tr = sample_weight.iloc[tr_idx]
            if is_pipeline:
                fit_kwargs = {f"{pipeline_step_name}__sample_weight": w_tr}
                model.fit(X_tr, y_tr, **fit_kwargs)
            else:
                model.fit(X_tr, y_tr, sample_weight=w_tr)
        else:
            model.fit(X_tr, y_tr)

        y_prob = model.predict_proba(X_va)[:, 1]
        roc_auc = roc_auc_score(y_va, y_prob)

        rows.append({
            "model": model_name,
            "fold": fold,
            "roc_auc": float(roc_auc),
        })

    cv_df = pd.DataFrame(rows)
    mean_row = pd.DataFrame([{
        "model": model_name,
        "fold": "mean",
        "roc_auc": float(cv_df["roc_auc"].mean()),
    }])

    return pd.concat([cv_df, mean_row], ignore_index=True)


def main() -> None:
    if not ML_READY_STRICT_FILE.exists():
        raise FileNotFoundError(f"No existe el dataset estricto: {ML_READY_STRICT_FILE}")

    if not SPLIT_ASSIGNMENTS_FILE.exists():
        raise FileNotFoundError(
            f"No existe el archivo de split reproducible: {SPLIT_ASSIGNMENTS_FILE}"
        )

    data = pd.read_csv(ML_READY_STRICT_FILE, low_memory=False)
    split_df = pd.read_csv(SPLIT_ASSIGNMENTS_FILE)

    missing_required = [c for c in REQUIRED_COLS if c not in data.columns]
    if missing_required:
        raise ValueError(
            f"Faltan columnas requeridas en el dataset estricto: {missing_required}"
        )

    required_split_cols = ["child_id", "split", "flourishing_all4"]
    missing_split_cols = [c for c in required_split_cols if c not in split_df.columns]
    if missing_split_cols:
        raise ValueError(
            f"Faltan columnas requeridas en el archivo de split: {missing_split_cols}"
        )

    # ------------------------------------------------------------
    # 1. Integrar split congelado
    # ------------------------------------------------------------
    if data["child_id"].duplicated().any():
        raise ValueError("child_id contiene duplicados en el dataset estricto.")

    if split_df["child_id"].duplicated().any():
        raise ValueError("child_id contiene duplicados en el archivo de split.")

    merged = data.merge(
        split_df[["child_id", "split"]],
        on="child_id",
        how="left",
        validate="one_to_one"
    )

    if merged["split"].isna().any():
        missing_ids = merged.loc[merged["split"].isna(), "child_id"].head(10).tolist()
        raise ValueError(
            f"Hay child_id sin asignación de split. Ejemplos: {missing_ids}"
        )

    # ------------------------------------------------------------
    # 2. Construir matrices
    # ------------------------------------------------------------
    feature_cols = [c for c in merged.columns if c not in REQUIRED_COLS + ["split"]]

    X_raw = merged[feature_cols].copy()
    y = merged["flourishing_all4"].copy()
    w = merged["FWC"].copy()

    X = clean_features(X_raw)

    train_mask = merged["split"] == "train"
    test_mask = merged["split"] == "test"

    X_train = X.loc[train_mask].reset_index(drop=True)
    X_test = X.loc[test_mask].reset_index(drop=True)

    y_train = y.loc[train_mask].reset_index(drop=True)
    y_test = y.loc[test_mask].reset_index(drop=True)

    w_train = w.loc[train_mask].reset_index(drop=True)
    w_test = w.loc[test_mask].reset_index(drop=True)  # reservado por si luego se necesita

    # ------------------------------------------------------------
    # 3. Definir modelos
    # ------------------------------------------------------------
    logistic_pipe = Pipeline([
        ("scaler", StandardScaler()),
        ("clf", LogisticRegression(
            max_iter=10000,
            solver="liblinear",
            random_state=RANDOM_STATE
        )),
    ])

    rf_model = RandomForestClassifier(
        n_estimators=500,
        random_state=RANDOM_STATE,
        n_jobs=-1
    )

    # ------------------------------------------------------------
    # 4. Entrenamiento y evaluación hold-out
    # ------------------------------------------------------------
    logistic_unweighted, fitted_logistic_unweighted = fit_and_evaluate_pipeline(
        model_name="logistic_unweighted",
        estimator=logistic_pipe,
        X_train=X_train,
        y_train=y_train,
        X_test=X_test,
        y_test=y_test,
        sample_weight=None,
        pipeline_step_name="clf",
    )
    logistic_unweighted.to_csv(LOGISTIC_RESULTS_FILE, index=False)

    logistic_weighted, fitted_logistic_weighted = fit_and_evaluate_pipeline(
        model_name="logistic_weighted",
        estimator=logistic_pipe,
        X_train=X_train,
        y_train=y_train,
        X_test=X_test,
        y_test=y_test,
        sample_weight=w_train,
        pipeline_step_name="clf",
    )
    logistic_weighted.to_csv(WEIGHTED_LOGISTIC_RESULTS_FILE, index=False)

    rf_unweighted, fitted_rf_unweighted = fit_and_evaluate_estimator(
        model_name="random_forest_unweighted",
        estimator=rf_model,
        X_train=X_train,
        y_train=y_train,
        X_test=X_test,
        y_test=y_test,
        sample_weight=None,
    )
    rf_unweighted.to_csv(RF_RESULTS_FILE, index=False)

    rf_weighted, fitted_rf_weighted = fit_and_evaluate_estimator(
        model_name="random_forest_weighted",
        estimator=rf_model,
        X_train=X_train,
        y_train=y_train,
        X_test=X_test,
        y_test=y_test,
        sample_weight=w_train,
    )
    rf_weighted.to_csv(WEIGHTED_RF_RESULTS_FILE, index=False)

    # Resumen conjunto
    model_summary = pd.concat(
        [logistic_unweighted, logistic_weighted, rf_unweighted, rf_weighted],
        ignore_index=True
    )
    model_summary.to_csv(MODEL_SUMMARY_FILE, index=False)

    # ------------------------------------------------------------
    # 5. Cross-validation SOLO en training
    # ------------------------------------------------------------
    cv_logistic_unweighted = cross_validate_model(
        model_name="logistic_unweighted",
        estimator=logistic_pipe,
        X_train=X_train,
        y_train=y_train,
        sample_weight=None,
        is_pipeline=True,
        pipeline_step_name="clf",
    )

    cv_logistic_weighted = cross_validate_model(
        model_name="logistic_weighted",
        estimator=logistic_pipe,
        X_train=X_train,
        y_train=y_train,
        sample_weight=w_train,
        is_pipeline=True,
        pipeline_step_name="clf",
    )

    cv_rf_unweighted = cross_validate_model(
        model_name="random_forest_unweighted",
        estimator=rf_model,
        X_train=X_train,
        y_train=y_train,
        sample_weight=None,
        is_pipeline=False,
    )

    cv_rf_weighted = cross_validate_model(
        model_name="random_forest_weighted",
        estimator=rf_model,
        X_train=X_train,
        y_train=y_train,
        sample_weight=w_train,
        is_pipeline=False,
    )

    cv_results = pd.concat(
        [
            cv_logistic_unweighted,
            cv_logistic_weighted,
            cv_rf_unweighted,
            cv_rf_weighted,
        ],
        ignore_index=True
    )
    cv_results.to_csv(CV_RESULTS_FILE, index=False)

    # ------------------------------------------------------------
    # 6. Coeficientes logísticos (modelo unweighted)
    # ------------------------------------------------------------
    logistic_coefficients = pd.DataFrame({
        "variable": feature_cols,
        "coefficient": fitted_logistic_unweighted.named_steps["clf"].coef_[0]
    }).sort_values(by="coefficient", key=lambda s: s.abs(), ascending=False)

    logistic_coefficients.to_csv(LOGISTIC_COEFFICIENTS_FILE, index=False)

    # ------------------------------------------------------------
    # 7. Reporte en consola
    # ------------------------------------------------------------
    print("=== Split utilizado ===")
    print("Train size:", len(X_train))
    print("Test size:", len(X_test))

    print("\n=== Hold-out results ===")
    print(model_summary.to_string(index=False))

    print("\n=== Cross-validation (training only) ===")
    print(cv_results.to_string(index=False))

    print("\n=== Top 10 coeficientes logísticos (unweighted) ===")
    print(logistic_coefficients.head(10).to_string(index=False))

    print("\nArchivos guardados:")
    print("Logistic unweighted:", LOGISTIC_RESULTS_FILE)
    print("Logistic weighted:", WEIGHTED_LOGISTIC_RESULTS_FILE)
    print("Random Forest unweighted:", RF_RESULTS_FILE)
    print("Random Forest weighted:", WEIGHTED_RF_RESULTS_FILE)
    print("Model summary:", MODEL_SUMMARY_FILE)
    print("Cross-validation:", CV_RESULTS_FILE)
    print("Logistic coefficients:", LOGISTIC_COEFFICIENTS_FILE)


if __name__ == "__main__":
    main()
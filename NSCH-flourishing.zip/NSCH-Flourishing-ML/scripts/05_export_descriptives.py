import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
import importlib.util

# Cargar dinámicamente 00_setup_paths.py
CURRENT_DIR = Path(__file__).resolve().parent
SETUP_FILE = CURRENT_DIR / "00_setup_paths.py"

spec = importlib.util.spec_from_file_location("setup_paths", SETUP_FILE)
setup_paths = importlib.util.module_from_spec(spec)
spec.loader.exec_module(setup_paths)

setup_paths.ensure_directories()

RAW_DATA_FILE = setup_paths.RAW_DATA_FILE
CLEAN_DATA_FILE = setup_paths.CLEAN_DATA_FILE
ML_READY_SELECTED_FILE = setup_paths.ML_READY_SELECTED_FILE
ML_READY_STRICT_FILE = setup_paths.ML_READY_STRICT_FILE
DATASET_SUMMARY_FILE = setup_paths.DATASET_SUMMARY_FILE
TARGET_DISTRIBUTION_FILE = setup_paths.TARGET_DISTRIBUTION_FILE
CODEBOOK_FILE = setup_paths.CODEBOOK_FILE
HEATMAP_FILE = setup_paths.HEATMAP_FILE

RESULTS_DIR = setup_paths.RESULTS_DIR
MUTUAL_INFO_FILE = setup_paths.MUTUAL_INFO_FILE

SAMPLE_FLOW_FILE = RESULTS_DIR / "sample_flow_summary.csv"

AGE_COL = "SC_AGE_YEARS"
AGE_MIN = 6
AGE_MAX = 17
FLOURISH_COLS = ["K6Q71_R", "K7Q84_R", "K7Q85_R", "K7Q82_R"]
VALID_RESPONSE_CODES = {1, 2, 3, 4}
INVALID_RESPONSE_CODES = {90, 95, 97, 98, 99}

REQUIRED_COLS = ["child_id", "flourishing_all4", "FWC", "STRATUM", "FIPSST"]

# Número máximo de variables para heatmap legible
HEATMAP_TOP_K = 25


def clean_features(df: pd.DataFrame) -> pd.DataFrame:
    X = df.copy()
    X = X.replace(r"^\s*$", np.nan, regex=True)
    X = X.replace(list(INVALID_RESPONSE_CODES), np.nan)

    for col in X.columns:
        X[col] = pd.to_numeric(X[col], errors="coerce")

    X = X.fillna(-1)
    return X


def validate_required_columns(df: pd.DataFrame, cols: list[str], label: str) -> None:
    missing = [c for c in cols if c not in df.columns]
    if missing:
        raise ValueError(f"Faltan columnas requeridas para {label}: {missing}")


def build_sample_flow(raw_df: pd.DataFrame, clean_df: pd.DataFrame) -> pd.DataFrame:
    validate_required_columns(raw_df, [AGE_COL] + FLOURISH_COLS, "flujo muestral")
    validate_required_columns(clean_df, ["flourishing_all4"], "dataset limpio")

    raw_n = len(raw_df)

    age_df = raw_df[raw_df[AGE_COL].between(AGE_MIN, AGE_MAX)].copy()
    age_n = len(age_df)

    valid_df = age_df.copy()
    for col in FLOURISH_COLS:
        valid_df = valid_df[valid_df[col].isin(VALID_RESPONSE_CODES)]
    valid_n = len(valid_df)

    clean_n = len(clean_df)

    flow = pd.DataFrame([
        {"step": "Raw NSCH 2023 records", "n": raw_n},
        {"step": f"Age-eligible records ({AGE_MIN}-{AGE_MAX} years)", "n": age_n},
        {"step": "Records with valid responses in all 4 flourishing items", "n": valid_n},
        {"step": "Final analytical dataset exported", "n": clean_n},
    ])

    flow["proportion_of_raw"] = flow["n"] / raw_n
    return flow


def build_dataset_summary(df: pd.DataFrame) -> pd.DataFrame:
    """
    Tabla breve y útil para el paper.
    Resume variables clave, no todo el dataset.
    """
    key_cols = ["flourishing_all4", "FWC", "STRATUM", "FIPSST"]

    # Incluir edad si está disponible en el dataset final
    if AGE_COL in df.columns:
        key_cols.append(AGE_COL)

    summary = df[key_cols].describe().T.reset_index()
    summary = summary.rename(columns={"index": "variable"})
    return summary


def build_target_distribution(df: pd.DataFrame) -> pd.DataFrame:
    target_dist = (
        df["flourishing_all4"]
        .value_counts(dropna=False)
        .sort_index()
        .reset_index()
    )
    target_dist.columns = ["flourishing_all4", "count"]
    target_dist["proportion"] = target_dist["count"] / target_dist["count"].sum()
    return target_dist


def build_codebook(df: pd.DataFrame) -> pd.DataFrame:
    codebook = pd.DataFrame({
        "variable": df.columns,
        "dtype": df.dtypes.astype(str).values,
        "missing_count": df.isna().sum().values,
        "non_missing_count": df.notna().sum().values,
        "nunique": [df[col].nunique(dropna=True) for col in df.columns],
    })
    return codebook.sort_values(by="variable").reset_index(drop=True)


def get_heatmap_variables(strict_df: pd.DataFrame) -> list[str]:
    """
    Selecciona variables para un heatmap legible.
    Prioriza el ranking MI si existe.
    """
    feature_cols = [c for c in strict_df.columns if c not in REQUIRED_COLS]

    if MUTUAL_INFO_FILE.exists():
        mi_df = pd.read_csv(MUTUAL_INFO_FILE)
        if {"variable", "strict_dataset"}.issubset(mi_df.columns):
            vars_from_mi = (
                mi_df.loc[mi_df["strict_dataset"] == 1, "variable"]
                .tolist()
            )
            vars_from_mi = [v for v in vars_from_mi if v in feature_cols]
            return vars_from_mi[:HEATMAP_TOP_K]

    return feature_cols[:HEATMAP_TOP_K]


def save_heatmap(strict_df: pd.DataFrame) -> None:
    validate_required_columns(strict_df, REQUIRED_COLS, "heatmap")

    heatmap_vars = get_heatmap_variables(strict_df)
    if len(heatmap_vars) < 2:
        raise ValueError("No hay suficientes variables para construir el heatmap.")

    X_heat = strict_df[heatmap_vars].copy()
    X_heat = clean_features(X_heat)

    corr = X_heat.corr()

    plt.figure(figsize=(14, 12))
    sns.heatmap(
        corr,
        cmap="coolwarm",
        annot=False,
        square=True,
        cbar_kws={"shrink": 0.8}
    )
    plt.title(f"Correlation heatmap of top {len(heatmap_vars)} benchmark features")
    plt.tight_layout()
    plt.savefig(HEATMAP_FILE, dpi=300, bbox_inches="tight")
    plt.close()


def main() -> None:
    if not RAW_DATA_FILE.exists():
        raise FileNotFoundError(f"No existe el archivo raw: {RAW_DATA_FILE}")

    if not CLEAN_DATA_FILE.exists():
        raise FileNotFoundError(f"No existe el dataset limpio: {CLEAN_DATA_FILE}")

    if not ML_READY_SELECTED_FILE.exists():
        raise FileNotFoundError(f"No existe el dataset seleccionado: {ML_READY_SELECTED_FILE}")

    if not ML_READY_STRICT_FILE.exists():
        raise FileNotFoundError(f"No existe el dataset estricto: {ML_READY_STRICT_FILE}")

    raw_df = pd.read_csv(RAW_DATA_FILE, low_memory=False)
    clean_df = pd.read_csv(CLEAN_DATA_FILE, low_memory=False)
    ml_dataset_selected = pd.read_csv(ML_READY_SELECTED_FILE, low_memory=False)
    ml_dataset_strict = pd.read_csv(ML_READY_STRICT_FILE, low_memory=False)

    validate_required_columns(ml_dataset_selected, ["flourishing_all4"], "selected dataset")
    validate_required_columns(ml_dataset_strict, REQUIRED_COLS, "strict dataset")

    # 1. Flujo muestral
    sample_flow = build_sample_flow(raw_df, clean_df)
    sample_flow.to_csv(SAMPLE_FLOW_FILE, index=False)

    # 2. Dataset summary breve
    dataset_summary = build_dataset_summary(ml_dataset_strict)
    dataset_summary.to_csv(DATASET_SUMMARY_FILE, index=False)

    # 3. Distribución del target
    target_dist = build_target_distribution(ml_dataset_strict)
    target_dist.to_csv(TARGET_DISTRIBUTION_FILE, index=False)

    # 4. Codebook del dataset benchmark final
    codebook = build_codebook(ml_dataset_strict)
    codebook.to_csv(CODEBOOK_FILE, index=False)

    # 5. Heatmap legible
    save_heatmap(ml_dataset_strict)

    print("Archivos generados correctamente:")
    print("Sample flow summary:", SAMPLE_FLOW_FILE)
    print("Dataset summary:", DATASET_SUMMARY_FILE)
    print("Target distribution:", TARGET_DISTRIBUTION_FILE)
    print("Codebook:", CODEBOOK_FILE)
    print("Heatmap:", HEATMAP_FILE)


if __name__ == "__main__":
    main()
import re
import pandas as pd
from pathlib import Path
import importlib.util

# Cargar dinámicamente 00_setup_paths.py
CURRENT_DIR = Path(__file__).resolve().parent
SETUP_FILE = CURRENT_DIR / "00_setup_paths.py"

spec = importlib.util.spec_from_file_location("setup_paths", SETUP_FILE)
setup_paths = importlib.util.module_from_spec(spec)
spec.loader.exec_module(setup_paths)

setup_paths.ensure_directories()

CLEAN_DATA_FILE = setup_paths.CLEAN_DATA_FILE
ML_READY_FULL_FILE = setup_paths.ML_READY_FULL_FILE
ML_READY_REDUCED_FILE = setup_paths.ML_READY_REDUCED_FILE

# ============================================================
# Configuración general
# ============================================================
INVALID_RESPONSE_CODES = {90, 95, 97, 98, 99}

REQUIRED_COLS = ["child_id", "flourishing_all4", "FWC", "STRATUM", "FIPSST"]

# Ítems fuente correctos del outcome
OUTCOME_SOURCE_COLS = [
    "K6Q71_R",  # interest/curiosity in learning new things
    "K7Q84_R",  # works to finish tasks started
    "K7Q85_R",  # stays calm and in control when challenged
    "K7Q82_R",  # cares about doing well in school
]

# Ítems antiguos incorrectos, excluidos por seguridad
LEGACY_WRONG_OUTCOME_COLS = [
    "K2Q35A",
    "K2Q35B",
    "K2Q35C",
    "K2Q35D",
    "K2Q35A_1_YEARS",
]

# No predictores por diseño / trazabilidad
NON_PREDICTOR_COLS = [
    "child_id",
    "HHID",
    "FWC",
    "STRATUM",
    "FIPSST",
    "flourishing_all4",
]

# Variables claramente derivadas del outcome o de sus mismas dimensiones
TARGET_PROXIMAL_EXACT_COLS = [
    "flrish6to17ct",
    "flrsh6to17ct",
    "flrsh0to5ct",
    "flourish6mto17_23",
    "flrish6to17_23",
    "nomFlrish6to17_23",
    "resil6to17_23",
    "curious6to17_23",
    "finishes_23",
    "cares_23",
    "SchlEngage_23",
    "homework_23",
    "K7Q83_R",
]

# Patrones para excluir familias completas muy cercanas al target
TARGET_RELATED_PATTERNS = [
    r"flrsh",
    r"flrish",
    r"flourish",
    r"nomflrish",
    r"curious6to17",
    r"resil6to17",
    r"^finishes(_|$)",
    r"^cares(_|$)",
    r"schlengage",
    r"^homework(_|$)",
]


def validate_required_columns(df: pd.DataFrame, cols: list[str], label: str) -> None:
    missing = [c for c in cols if c not in df.columns]
    if missing:
        raise ValueError(f"Faltan columnas requeridas para {label}: {missing}")


def is_target_related_column(col_name: str) -> bool:
    """
    Devuelve True si la columna debe excluirse por estar directa o
    indirectamente relacionada con el target.
    """
    if col_name in OUTCOME_SOURCE_COLS:
        return True

    if col_name in LEGACY_WRONG_OUTCOME_COLS:
        return True

    if col_name in NON_PREDICTOR_COLS:
        return True

    if col_name in TARGET_PROXIMAL_EXACT_COLS:
        return True

    lower_name = col_name.lower()
    for pattern in TARGET_RELATED_PATTERNS:
        if re.search(pattern, lower_name, flags=re.IGNORECASE):
            return True

    return False


def substantive_mask(series: pd.Series) -> pd.Series:
    """
    Máscara de valores sustantivos:
    - no NaN
    - no pertenecen a códigos no sustantivos del NSCH
    """
    return series.notna() & (~series.isin(INVALID_RESPONSE_CODES))


def valid_ratio(series: pd.Series) -> float:
    mask = substantive_mask(series)
    return float(mask.mean())


def substantive_nunique(series: pd.Series) -> int:
    mask = substantive_mask(series)
    return int(series[mask].nunique(dropna=True))


def main() -> None:
    if not CLEAN_DATA_FILE.exists():
        raise FileNotFoundError(f"No existe el dataset limpio: {CLEAN_DATA_FILE}")

    df = pd.read_csv(CLEAN_DATA_FILE, low_memory=False)

    validate_required_columns(df, REQUIRED_COLS, "dataset limpio")
    validate_required_columns(df, OUTCOME_SOURCE_COLS, "verificación de columnas fuente del outcome")

    all_columns = list(df.columns)

    excluded_target_related = [c for c in all_columns if is_target_related_column(c)]
    candidate_features = [c for c in all_columns if not is_target_related_column(c)]

    # Primer filtro: al menos 50% de datos sustantivos
    valid_features = []
    dropped_low_valid_50 = []

    for col in candidate_features:
        ratio = valid_ratio(df[col])
        if ratio > 0.50:
            valid_features.append(col)
        else:
            dropped_low_valid_50.append(col)

    cols_full = REQUIRED_COLS + valid_features
    ml_dataset_full = df[cols_full].copy()
    ml_dataset_full.to_csv(ML_READY_FULL_FILE, index=False)

    # Eliminar variables sin variabilidad sustantiva
    low_variance = []
    features_step2 = []

    for col in valid_features:
        n_unique = substantive_nunique(df[col])
        if n_unique <= 1:
            low_variance.append(col)
        else:
            features_step2.append(col)

    # Segundo filtro: al menos 70% de datos sustantivos
    features_step3 = []
    dropped_low_valid_70 = []

    for col in features_step2:
        ratio = valid_ratio(df[col])
        if ratio > 0.70:
            features_step3.append(col)
        else:
            dropped_low_valid_70.append(col)

    cols_reduced = REQUIRED_COLS + features_step3
    ml_dataset_reduced = df[cols_reduced].copy()
    ml_dataset_reduced.to_csv(ML_READY_REDUCED_FILE, index=False)

    print("=== Verificación de exclusión por target / leakage ===")
    print("Columnas excluidas por relación con target:", len(excluded_target_related))

    preview = sorted(excluded_target_related)[:80]
    for name in preview:
        print("  -", name)

    must_be_excluded = [
        "flrish6to17_23",
        "nomFlrish6to17_23",
        "resil6to17_23",
        "finishes_23",
        "curious6to17_23",
        "cares_23",
        "SchlEngage_23",
        "homework_23",
        "K7Q83_R",
        "flrsh6to17ct",
    ]

    print("\n=== Chequeo de exclusiones críticas ===")
    for var in must_be_excluded:
        if var in excluded_target_related:
            print(f"[OK] {var} excluida")
        else:
            print(f"[WARN] {var} NO fue excluida")

    print("\n=== Resumen de filtros ===")
    print("Total columnas originales:", len(all_columns))
    print("candidate_features:", len(candidate_features))
    print("valid_features (>50% sustantivos):", len(valid_features))
    print("dropped_low_valid_50:", len(dropped_low_valid_50))
    print("low_variance (<=1 valor sustantivo):", len(low_variance))
    print("features_step3 (>70% sustantivos):", len(features_step3))
    print("dropped_low_valid_70:", len(dropped_low_valid_70))

    print("\n=== Shapes exportados ===")
    print("Shape ml_dataset_full:", ml_dataset_full.shape)
    print("Shape ml_dataset_reduced:", ml_dataset_reduced.shape)

    print("\nArchivos guardados:")
    print("Full dataset:", ML_READY_FULL_FILE)
    print("Reduced dataset:", ML_READY_REDUCED_FILE)


if __name__ == "__main__":
    main()
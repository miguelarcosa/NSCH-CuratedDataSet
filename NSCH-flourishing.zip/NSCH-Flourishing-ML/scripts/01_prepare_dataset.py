import pandas as pd
from pathlib import Path
import importlib.util

# Cargar dinámicamente 00_setup_paths.py
CURRENT_DIR = Path(__file__).resolve().parent
SETUP_FILE = CURRENT_DIR / "00_setup_paths.py"

spec = importlib.util.spec_from_file_location("setup_paths", SETUP_FILE)
setup_paths = importlib.util.module_from_spec(spec)
spec.loader.exec_module(setup_paths)

setup_paths.ensure_directories()

RAW_DATA_FILE = setup_paths.RAW_DATA_FILE
CLEAN_DATA_FILE = setup_paths.CLEAN_DATA_FILE
ML_READY_BASIC_FILE = setup_paths.ML_READY_BASIC_FILE

# ============================================================
# Definición correcta del outcome de flourishing (edad 6-17)
# ============================================================
AGE_COL = "SC_AGE_YEARS"
AGE_MIN = 6
AGE_MAX = 17

FLOURISH_COLS = [
    "K6Q71_R",  # Shows interest and curiosity in learning new things
    "K7Q84_R",  # Works to finish tasks started
    "K7Q85_R",  # Stays calm and in control when challenged
    "K7Q82_R",  # Cares about doing well in school
]

POSITIVE_CODES = {1, 2}   # Always / Usually
NEGATIVE_CODES = {3, 4}   # Sometimes / Never
VALID_RESPONSE_CODES = POSITIVE_CODES | NEGATIVE_CODES

# Códigos no sustantivos frecuentes en NSCH
INVALID_RESPONSE_CODES = {90, 95, 97, 98, 99}


def validate_required_columns(df: pd.DataFrame, cols: list[str], label: str) -> None:
    missing = [c for c in cols if c not in df.columns]
    if missing:
        raise ValueError(f"Faltan columnas requeridas para {label}: {missing}")


def build_flourishing_target(df: pd.DataFrame) -> pd.Series:
    """
    Crea el target binario flourishing_all4.
    1 = las cuatro respuestas son Always/Usually (códigos 1 o 2)
    0 = al menos una respuesta válida es Sometimes/Never (3 o 4)

    Se asume que previamente el dataframe ya fue filtrado para conservar
    únicamente respuestas válidas en las cuatro variables.
    """
    return (
        df[FLOURISH_COLS]
        .apply(lambda row: all(value in POSITIVE_CODES for value in row), axis=1)
        .astype(int)
    )


def main() -> None:
    if not RAW_DATA_FILE.exists():
        raise FileNotFoundError(f"No se encontró el archivo fuente: {RAW_DATA_FILE}")

    df = pd.read_csv(RAW_DATA_FILE, low_memory=False)

    validate_required_columns(df, [AGE_COL] + FLOURISH_COLS, "construcción del outcome")

    n_raw = len(df)

    # ------------------------------------------------------------
    # 1. Filtrar población elegible por edad: 6 a 17 años
    # ------------------------------------------------------------
    df_age = df[df[AGE_COL].between(AGE_MIN, AGE_MAX)].copy()
    n_age_eligible = len(df_age)

    # ------------------------------------------------------------
    # 2. Filtrar filas con respuestas válidas en los 4 ítems
    #    del outcome (excluir skips, missing y otros no válidos)
    # ------------------------------------------------------------
    df_valid = df_age.copy()

    for col in FLOURISH_COLS:
        df_valid = df_valid[df_valid[col].isin(VALID_RESPONSE_CODES)]

    n_valid_outcome = len(df_valid)

    # ------------------------------------------------------------
    # 3. Crear target binario
    # ------------------------------------------------------------
    df_valid["flourishing_all4"] = build_flourishing_target(df_valid)

    # ------------------------------------------------------------
    # 4. Resetear índice y crear identificador limpio
    # ------------------------------------------------------------
    df_valid = df_valid.reset_index(drop=True)
    df_valid["child_id"] = range(len(df_valid))

    # ------------------------------------------------------------
    # 5. Guardar dataset limpio completo
    # ------------------------------------------------------------
    df_valid.to_csv(CLEAN_DATA_FILE, index=False)

    # ------------------------------------------------------------
    # 6. Crear dataset ML básico
    # ------------------------------------------------------------
    basic_cols = [
        "child_id",
        "flourishing_all4",
        "FWC",
        "STRATUM",
        "FIPSST",
        "SC_AGE_YEARS",
        "SC_SEX",
        "TOTKIDS_R",
        "TENURE",
        "HHLANGUAGE",
    ]

    validate_required_columns(df_valid, basic_cols, "dataset ML básico")

    ml_dataset_basic = df_valid[basic_cols].copy()
    ml_dataset_basic.to_csv(ML_READY_BASIC_FILE, index=False)

    # ------------------------------------------------------------
    # 7. Reporte en consola
    # ------------------------------------------------------------
    target_counts = df_valid["flourishing_all4"].value_counts().sort_index()
    target_props = df_valid["flourishing_all4"].value_counts(normalize=True).sort_index()

    print("Archivo fuente:", RAW_DATA_FILE)
    print("Dataset limpio guardado en:", CLEAN_DATA_FILE)
    print("Dataset ML básico guardado en:", ML_READY_BASIC_FILE)

    print("\n=== Flujo muestral ===")
    print(f"Registros originales: {n_raw}")
    print(f"Elegibles por edad ({AGE_MIN}-{AGE_MAX} años): {n_age_eligible}")
    print(f"Casos con 4 ítems válidos de flourishing: {n_valid_outcome}")

    print("\n=== Shape dataset limpio ===")
    print(df_valid.shape)

    print("\n=== Distribución de flourishing_all4 ===")
    for cls in sorted(target_counts.index):
        print(
            f"Clase {cls}: {target_counts[cls]} "
            f"({target_props[cls]:.4f})"
        )

    print("\n=== Verificación rápida de variables del outcome ===")
    print(df_valid[FLOURISH_COLS].describe(include="all"))


if __name__ == "__main__":
    main()
import pandas as pd
from pathlib import Path
import importlib.util

# Cargar dinámicamente 00_setup_paths.py
CURRENT_DIR = Path(__file__).resolve().parent
SETUP_FILE = CURRENT_DIR / "00_setup_paths.py"

spec = importlib.util.spec_from_file_location("setup_paths", SETUP_FILE)
setup_paths = importlib.util.module_from_spec(spec)
spec.loader.exec_module(setup_paths)

setup_paths.ensure_directories()

# Archivos de entrada
DATASET_SUMMARY_FILE = setup_paths.DATASET_SUMMARY_FILE
TARGET_DISTRIBUTION_FILE = setup_paths.TARGET_DISTRIBUTION_FILE
MUTUAL_INFO_FILE = setup_paths.MUTUAL_INFO_FILE
LOGISTIC_RESULTS_FILE = setup_paths.LOGISTIC_RESULTS_FILE
WEIGHTED_LOGISTIC_RESULTS_FILE = setup_paths.WEIGHTED_LOGISTIC_RESULTS_FILE
RF_RESULTS_FILE = setup_paths.RF_RESULTS_FILE
CV_RESULTS_FILE = setup_paths.CV_RESULTS_FILE

RESULTS_DIR = setup_paths.RESULTS_DIR
SAMPLE_FLOW_FILE = RESULTS_DIR / "sample_flow_summary.csv"
WEIGHTED_RF_RESULTS_FILE = RESULTS_DIR / "weighted_random_forest_results.csv"
MODEL_SUMMARY_FILE = RESULTS_DIR / "baseline_model_results_summary.csv"

# Archivos de salida
TABLE_DATASET_FILE = setup_paths.TABLE_DATASET_FILE
TABLE_FEATURE_SELECTION_FILE = setup_paths.TABLE_FEATURE_SELECTION_FILE
TABLE_MODEL_RESULTS_FILE = setup_paths.TABLE_MODEL_RESULTS_FILE


def latex_float(x: float, digits: int = 4) -> str:
    return f"{x:.{digits}f}"


def export_dataset_table() -> None:
    required_files = [
        SAMPLE_FLOW_FILE,
        DATASET_SUMMARY_FILE,
        TARGET_DISTRIBUTION_FILE,
    ]

    for fp in required_files:
        if not fp.exists():
            raise FileNotFoundError(f"No existe: {fp}")

    sample_flow = pd.read_csv(SAMPLE_FLOW_FILE)
    summary = pd.read_csv(DATASET_SUMMARY_FILE)
    target = pd.read_csv(TARGET_DISTRIBUTION_FILE)

    # ------------------------------------------------------------
    # 1. Sample flow table
    # ------------------------------------------------------------
    flow_tbl = sample_flow.copy()
    if "proportion_of_raw" in flow_tbl.columns:
        flow_tbl["proportion_of_raw"] = flow_tbl["proportion_of_raw"].map(lambda x: latex_float(x, 4))

    latex_flow = flow_tbl.to_latex(
        index=False,
        caption="Sample construction flow from the raw NSCH 2023 file to the final analytical dataset.",
        label="tab:sample_flow",
        escape=False
    )

    # ------------------------------------------------------------
    # 2. Descriptive summary table
    # ------------------------------------------------------------
    vars_of_interest = ["flourishing_all4", "FWC", "STRATUM", "FIPSST", "SC_AGE_YEARS"]
    available_vars = [v for v in vars_of_interest if v in summary["variable"].tolist()]

    cols_to_keep = ["variable", "count", "mean", "std", "min", "max"]
    summary_tbl = summary[summary["variable"].isin(available_vars)].copy()
    summary_tbl = summary_tbl[cols_to_keep]

    for col in ["count", "mean", "std", "min", "max"]:
        if col in summary_tbl.columns:
            summary_tbl[col] = summary_tbl[col].map(lambda x: latex_float(x, 4))

    latex_summary = summary_tbl.to_latex(
        index=False,
        caption="Descriptive statistics of key variables in the benchmark dataset.",
        label="tab:dataset_summary",
        escape=False
    )

    # ------------------------------------------------------------
    # 3. Target distribution table
    # ------------------------------------------------------------
    target_tbl = target.copy()
    if "proportion" in target_tbl.columns:
        target_tbl["proportion"] = target_tbl["proportion"].map(lambda x: latex_float(x, 4))

    latex_target = target_tbl.to_latex(
        index=False,
        caption="Distribution of the target variable \\texttt{flourishing\\_all4}.",
        label="tab:target_distribution",
        escape=False
    )

    with open(TABLE_DATASET_FILE, "w", encoding="utf-8") as f:
        f.write("% Table A: Sample flow\n")
        f.write(latex_flow)
        f.write("\n\n% Table B: Dataset summary\n")
        f.write(latex_summary)
        f.write("\n\n% Table C: Target distribution\n")
        f.write(latex_target)


def export_feature_selection_table() -> None:
    if not MUTUAL_INFO_FILE.exists():
        raise FileNotFoundError(f"No existe: {MUTUAL_INFO_FILE}")

    mi = pd.read_csv(MUTUAL_INFO_FILE)

    required_cols = {"rank", "variable", "mutual_information"}
    if not required_cols.issubset(mi.columns):
        raise ValueError(
            f"El archivo de MI no contiene las columnas esperadas: {required_cols}"
        )

    # Si existe strict_dataset, priorizamos las features del subset final
    if "strict_dataset" in mi.columns:
        mi_tbl = mi.loc[mi["strict_dataset"] == 1, ["rank", "variable", "mutual_information"]].copy()
    else:
        mi_tbl = mi[["rank", "variable", "mutual_information"]].copy()

    mi_tbl = mi_tbl.sort_values(by="rank").head(15).copy()
    mi_tbl["mutual_information"] = mi_tbl["mutual_information"].map(lambda x: f"{x:.6f}")

    latex_mi = mi_tbl.to_latex(
        index=False,
        caption="Top 15 predictors in the final benchmark subset ranked by mutual information computed on the training partition only.",
        label="tab:feature_selection",
        escape=False
    )

    with open(TABLE_FEATURE_SELECTION_FILE, "w", encoding="utf-8") as f:
        f.write(latex_mi)


def normalize_model_name(name: str) -> tuple[str, str]:
    mapping = {
        "logistic_unweighted": ("Logistic Regression", "Unweighted"),
        "logistic_weighted": ("Logistic Regression", "Weighted"),
        "random_forest_unweighted": ("Random Forest", "Unweighted"),
        "random_forest_weighted": ("Random Forest", "Weighted"),
        "random_forest": ("Random Forest", "Unweighted"),
    }
    return mapping.get(name, (name, ""))


def export_model_results_table() -> None:
    # ------------------------------------------------------------
    # 1. Hold-out results
    # ------------------------------------------------------------
    if MODEL_SUMMARY_FILE.exists():
        model_results = pd.read_csv(MODEL_SUMMARY_FILE)
    else:
        required_files = [
            LOGISTIC_RESULTS_FILE,
            WEIGHTED_LOGISTIC_RESULTS_FILE,
            RF_RESULTS_FILE,
        ]
        for fp in required_files:
            if not fp.exists():
                raise FileNotFoundError(f"No existe: {fp}")

        frames = [
            pd.read_csv(LOGISTIC_RESULTS_FILE),
            pd.read_csv(WEIGHTED_LOGISTIC_RESULTS_FILE),
            pd.read_csv(RF_RESULTS_FILE),
        ]

        if WEIGHTED_RF_RESULTS_FILE.exists():
            frames.append(pd.read_csv(WEIGHTED_RF_RESULTS_FILE))

        model_results = pd.concat(frames, ignore_index=True)

    if "model" not in model_results.columns:
        raise ValueError("El resumen de modelos no contiene la columna 'model'.")

    holdout_tbl = model_results.copy()
    holdout_tbl[["Model", "Weighting"]] = holdout_tbl["model"].apply(
        lambda x: pd.Series(normalize_model_name(str(x)))
    )

    holdout_tbl = holdout_tbl[["Model", "Weighting", "accuracy", "f1", "roc_auc"]].copy()
    holdout_tbl = holdout_tbl.rename(columns={
        "accuracy": "Accuracy",
        "f1": "F1",
        "roc_auc": "ROC-AUC",
    })

    for col in ["Accuracy", "F1", "ROC-AUC"]:
        holdout_tbl[col] = holdout_tbl[col].map(lambda x: latex_float(x, 4))

    latex_holdout = holdout_tbl.to_latex(
        index=False,
        caption="Hold-out performance of the baseline models on the final benchmark dataset.",
        label="tab:model_results",
        escape=False
    )

    # ------------------------------------------------------------
    # 2. Cross-validation mean results (training only)
    # ------------------------------------------------------------
    if not CV_RESULTS_FILE.exists():
        raise FileNotFoundError(f"No existe: {CV_RESULTS_FILE}")

    cv = pd.read_csv(CV_RESULTS_FILE)

    required_cv_cols = {"model", "fold", "roc_auc"}
    if not required_cv_cols.issubset(cv.columns):
        raise ValueError(
            f"El archivo de CV no contiene las columnas esperadas: {required_cv_cols}"
        )

    cv_mean_tbl = cv.loc[cv["fold"].astype(str) == "mean", ["model", "roc_auc"]].copy()
    cv_mean_tbl[["Model", "Weighting"]] = cv_mean_tbl["model"].apply(
        lambda x: pd.Series(normalize_model_name(str(x)))
    )

    cv_mean_tbl = cv_mean_tbl[["Model", "Weighting", "roc_auc"]].copy()
    cv_mean_tbl = cv_mean_tbl.rename(columns={"roc_auc": "Mean ROC-AUC"})
    cv_mean_tbl["Mean ROC-AUC"] = cv_mean_tbl["Mean ROC-AUC"].map(lambda x: latex_float(x, 4))

    latex_cv_mean = cv_mean_tbl.to_latex(
        index=False,
        caption="Five-fold cross-validation mean ROC-AUC on the training partition.",
        label="tab:cv_results",
        escape=False
    )

    with open(TABLE_MODEL_RESULTS_FILE, "w", encoding="utf-8") as f:
        f.write("% Table A: Hold-out results\n")
        f.write(latex_holdout)
        f.write("\n\n% Table B: Cross-validation means\n")
        f.write(latex_cv_mean)


def main() -> None:
    export_dataset_table()
    export_feature_selection_table()
    export_model_results_table()

    print("Tablas LaTeX generadas correctamente:")
    print("Dataset tables:", TABLE_DATASET_FILE)
    print("Feature selection table:", TABLE_FEATURE_SELECTION_FILE)
    print("Model results tables:", TABLE_MODEL_RESULTS_FILE)


if __name__ == "__main__":
    main()